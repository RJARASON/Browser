**To start the program**

*Open 'Main_Login' and run!*
----------



**To Login into the Transaction Program**


*Login credentials*

username : user

pin : 0000




